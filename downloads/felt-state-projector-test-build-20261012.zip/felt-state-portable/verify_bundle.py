"""Verify the portable demo without importing UI or ML packages."""
import hashlib
import json
from pathlib import Path
root = Path(__file__).resolve().parent
hashes = json.loads((root / 'bundle_hashes.json').read_text())
for name, expected in hashes.items():
    actual = hashlib.sha256((root / name).read_bytes()).hexdigest()
    if actual != expected:
        raise SystemExit('Changed or incomplete bundle: ' + name)
from demo.core import ReplayProjector, evaluation
assert len(ReplayProjector().records) == 16
evaluation.validate_package()
print('Demo bundle intact; 16 recorded responses. No model loaded or API call made.')

status = json.loads((root / 'BUILD_STATUS.json').read_text())
if status['model_included']:
    from portable.export_portable_run import read_run
    read_run(root / 'felt-state-model/run')
print('Portable status:', status['status'])
print('Reference laptop evidence included; this setup script has not been tested on a GPU.')
print('Other hosts and judge receiver access remain unverified.')
